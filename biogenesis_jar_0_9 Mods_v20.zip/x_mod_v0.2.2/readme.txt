--- GENERAL INFORMATION ------------------------------------------------

Biogenesis X Mod is a modification of the original evolution simulation 
& artificial life project by Joan Queralt Molina:
https://sourceforge.net/projects/biogenesis/
In both, the original project and this modification, 2-dimensional
organisms consisting of line segments interact with each other,
reproduce and evolve in time.

Compared to the original project, this modification explores the
following features:
 * alternative mutation mechanisms
 * an alternative stress-based aging mechanism

It is based on the new_design branch of Biogenesis
(https://sourceforge.net/p/biogenesis/git/ci/new_design/tree/), its
source code can be obatained from
http://sourceforge.net/p/biogenesisxmod/code/ci/xmod/tree/

Biogenesis X Mod site at sourceforge: 
https://sourceforge.net/projects/biogenesisxmod/

Contact: Adam Muschielok: imabu@users.sourceforge.net

=== VERSION 0.2.2 released 2015-01-27 ==================================
CHANGES:
* The frequency of mutations is based on rates (i.e. average number of
  mutations per frame) now instead of probabilities. 
* All kinds of mutations are balanced now, i.e. they do not cause
  systematic drift in the genetic code when there is no selection. 
* Split/merge mutation can produce segments with an arbitrary color.
* Adapted default segment probabilities slightly.

BUGFIXES:
* Split/merge mutations were not balanced and made organisms shrink on
  the long term - this is fixed now.
* Preferences on mutation parameters and stress resistance are saved
  now.
* Pasting the same genetic code from the clipboard was leading to
  identical mutations in all organisms created in that way (i.e. the
  organimsms mutated synchronously) - this is fixed now. 

=== VERSION 0.2.1 released 2015-01-03 ==================================
NEW FEATURES:
 * Mutations of an organism can now occur spontaneously. This prevents
   that evolution "gets stuck" if there are only very successful
   almost immortal organisms in the world that do not reproduce
   successfully.
   The rate of spontaneous mutations is controlled by the "spontaneous
   mutation probability" in the menu World > Parameters > Organisms.
   Currently, spontaneous mutations are limited to splitting or merging
   segments and color changes of segments. 
 * The average length of the yellow segments has an influence on how
   the parent organism's energy is distributed between parent and
   children during reproduction.
   An organism with long yellow segments gives most of its energy to its
   children and keeps only a small amount for itself, producing stronger
   children but weakening itself. An organism with short yellow segments
   will transfer just a small amount of its own energy to its children
   that are weak, but stays relatively strong.

CHANGES:
 * Growth and reproduction of an organism depends on the stress level
   now:
   - reproduction is allowed only if
     stress level <= REPRODUCTION_MAX_STRESS_LEVEL, which is currently
     set to 0.05
   - growth is allowed only if stress level <= GROW_MAX_STRESS_LEVEL,
     which is currently set to 0.1
 * Introduced minimum energy that describes how much of the organisms
   energy is bound to the body. In that way the bodies of dead organisms
   remain in the world and can decay like in versions 0.1.x.
 * The stress level is adjusted so that not fully grown organisms do
   not experience disadvantages unless they get attacked.
 * After reproduction, the body of the parent organism shrinks in order
   to remain unaffected by the loss of energy caused by reproduction.

BUGFIXES:
 * decay energy was not read from edit box, fixed now
 * fixed freezing of organisms at the world borders (happened only
   sometimes)

=== VERSION 0.2.0 released 2014-12-18 ==================================
NEW FEATURES:
 * There is no maximum life expectancy for organisms anymore
 * Aging mechanism was revised:
   - Organisms possess a stress level that determines how often the
     segments stop to work correctly. The higher the stress level the
     more often a segment will fail.
   - The stress level is determined as the ratio of the current energy
     to the energy needed for reproduction.
   - Organisms possess a stress resistance, the higher it is the less
     energy organisms can have without being affected by stress.
     The stress resistance can be set as a parameter instead of maximum
     age now in the menu World > Parameters > Organisms.

CHANGES:
 * renamed "rubbing" into "friction"

BUGFIXES:
 * division by 0 exception in painting the average color composition in
   the statistics window fixed


========================================================================
=== VERSION 0.1.1 released 2014-12-16 ==================================
BUGFIXES:
 * program crash immediately after start on german locale fixed


=== VERSION 0.1.0 released 2014-12-14 ==================================
NEW FEATURES:
 * new minor mutation mechanisms
   - small independent changes in segment lengths and angles
   - split a segment into two segments / merge two adjacent segments,
     both without changing the orientation of the other segments
   - make the organism bigger / smaller
 * new major mutation mechanisms (formerly the only mutation mechanism
   available)
   - flip several adjacent segments around the axis that connects the
     ends of the flipped region
   - interchange (swap) two segments while keeping the orientation of
     all segments constant
 * probabilities of major and minor mutations, as well as the amplitude
   of minor mutations are controllable from the menu
   World > Parameters > Organisms

CHANGES:
 * major mutation that adds/removes a gene keeps now the orientation of
   the remaining segments constant.

BUGFIXES:
 * child overlap bug is fixed now using a commit from the
   PortingColorMod branch of the original Biogenesis project 
 * icons disappeared when program was run from a JAR file because of
   incorrect path to image resources
