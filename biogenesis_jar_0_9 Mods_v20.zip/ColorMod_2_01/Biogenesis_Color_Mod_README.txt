﻿<Biogenesis Color Mod 2.01 readme>

ATTENTION: Please set your parameters to default (first start), 
           because the Color Mod isn´t compatible with vanilla default settings,
           or even older Color Mod default settings.
           I also mostly tested with default settings and these should work fine.

Original program by Joan Queralt Molina (thanks for the great work)
http://sourceforge.net/projects/biogenesis/

Color Mod by MarcoDBAA:

Preliminary notes:
 -You need Java to run Biogenesis.
 -If you did not play Biogenesis 0.8, you may read the original manual first: 
  http://biogenesis.sourceforge.net/manual.php.en
 -If you do not like all new colors of the Color Mod, 
  set the respective probability to 0 and these colors will not be a part of the simulation.
 -If the simulation lags for you, just reduce the "Initial carbon dioxide" in "Parameters/World"
  (if you do that, you may reduce the size of the world too).
 -If you set "Time per frame" to "1", the simulation should run faster than default value "2",
  but FPS shown will be bugged (always at 1000, also in Biogenesis 0.8), unsure why it is the case.
 -If you open a Google Chrome window (or another browser or program?), simulation speed will be 
  super fast, if the computer core running Biogenesis isn´t working to capacity yet.
 -Some newer CPUs have performance cores and efficiency cores, and you should deactivate the slower
  efficiency cores for Biogenesis in processor affinity after starting it (each start),
  because Biogenesis runs on only one core, and might (will in my case) use the slower ones.

Changes:

1. Translations:
   -German translation by myself
   -Portuguese translation (thanks to Maurício Leonardi)
   -Russian translation (thanks to Alexey Loginov)

2. Bug fixes:
   -Fixed a bug where organisms disappeared from the world after a collision, 
    or immediately at birth (if they were very small).
   -Fixed a bug, where you couldn´t change the value for the parameter 
    "Energy lost by dead organisms".
   -Fixed a bug, where the statistics window didn´t work in empty worlds.
   -Fixed a bug, where mostly very small organisms repeatedly grew and shrunk.
   -Fixed a bug, where "Resume process" and "Pause process" switched positions.

3. New Parameter:
   -New default parameter settings
   -"Initial methane": Amount of methane that there is in the atmosphere of a new world.
   -"CO2 to CH4 divisor": Total amount of CO2 turned into CH4 each frame, divided by this number.
   -"CH4 to CO2 divisor": Total amount of CH4 turned into CO2 each frame, divided by this number.
   -"Initial complexity": Maximum number of genes of new random organisms.
   -"Clade complexity": Number of subclades, that are shown in the Info toolbar (see 12.).
   -"Meta mutation ‱": Global mutation rate of the mutation rate (0-10000; 100 ‱ = 1%).
   -"Min mutation ‱": Minimal possible mutation rate for an organism (0-10000; 100 ‱ = 1%).
   -"Max mutation ‱": Maximal possible mutation rate for an organism (0-10000; 100 ‱ = 1%).
   -"Life expectancy": basis life for all organisms.
   -"Life expectancy divisor": segments/divisor = added life.
   -"Cream released energy proportion": Released energy proportion for CREAM
   -"Healing delay": Random, but less effective, if this value is high for MAGENTA.
   -"Immune system delay": Random, but less effective, if this value is high for MINT.
   -"Jade Healing delay": Random, but less effective, if this value is high for JADE.
   -"Lavender Shield": LAVENDER barrier, higher values make it last longer.
   -"Indigo divisor": Divides the effective amount of INDIGO, makes it less effective.
   -"Dodge cost": Used by passive non consumers with TEAL segments
     and C4 plants with no other photosynthetic segments
   -"Spike consumer cost": for enhanced SPIKE. 
   -"Silver consumer cost": for feeding SILVER.
   -"Non-plant white cost": Used by WHITE, if the organism is not a plant.
   -"Non-plant plague cost": Used by PLAGUE, if the organism is not a plant (or not a virus).
   -"Lime effectivity if not alone": LIME photosynthesis if crowded.
   -"+ Forest effectivity if not alone": Added FOREST photosynthesis if crowded.
   -"+ Photosynthetic effectivity with symbiont": Added photosynthesis, if the organism
    touches an organism with ROSE segments, that is neither a plant nor a consumer
     
4. Mutations:
   -Organisms have an individual mutation rate now, adjustable in the Genetic Laboratory
   -Possible values are "Min mutation ‱" to "Max mutation ‱"
   -If you change these values during a simulation newly born organisms mutation rates
    will increase or decrease, if they are below or above these new limits
   -if a mutation of the mutation rate happens:
    -1/10 chance to be a large change, either decrease the mutation rate between "Min mutation ‱"
     and current mutation rate, or increase it between current mutation rate and "Max mutation ‱"
    -9/10 chance to be a small change, either decrease the mutation rate by 1 or 2,
     or increase it by 1 or 2 
   -Attention: High mutation rates are ineffective and will also slow down the simulation
   -"Better" function to create random organisms, independent from symmetry
   -Through mutation organisms can have between 1 and 100 segment genes (was 4-64 total segments)
   -Now randomization of symmetry is completely random. Was biased with 
    respect to similar symmetries, but created much more 1-symmetric organisms, 
    if the mother was 8-symmetric. For this reason I changed it.
   -A gene can be cloned:
    -The new gene will be before or after the old gene.
    -Chance to have a cloned gene instead of a new gene is 1/8
    -Length will be randomized in 50% of all cloned genes
    -Rotation will always be randomized
    -Branch will be randomized in 20% of all cloned genes.
    -If the cloned gene is after the old gene, and wasn´t randomized, it starts,
     where the old gene started in 50% of all cases, or else where the old gene ended
    -If the cloned gene is before the old gene, and wasn´t randomized, branching is copied 

5. New Life expectancy: 
   -default lifespan 
   - "+" number of organisms segments divided by life expectancy divisor 
   - "+" GOLD segments (see below) 
     
6. New genes (Genetic Laboratory):
   -"Generation conflict": if "Yes": parent and children attack each other
   -"Sibling rivalry": if "Yes": siblings attack each other
   -"Selfish mother": 
     -if "Yes": mother always retains half of the energy (not vs infections), if she reproduces.
     -if "No" : mother distributes the energy equally for herself and all children.                  
   -"Altruist": see MAGENTA, MINT, LAVENDER and ROSE color and "Familial" below
   -"Familial": if family relations are friendly...
     -MAGENTA: heals parents, children and siblings
     -MINT: removes infections from parents, children and siblings and restores time to reproduce
     -LAVENDER: gives parents, childrens and siblings shield energy
     -ROSE: transfers energy to parents, children and siblings
     -costs for use of MAGENTA and MINT are shared between helper and helped (no costs for LAVENDER) 
   -"Peaceful": Peaceful organisms with ROSE segments don´t attack each other
   -"Social": Social organisms with ROSE segments of the same length and theta don´t attack each other
    (exception: plants and consumers attack organisms, that are neither, and the reverse is true)       
   -"Passive": see TEAL color
   -"Clockwise": see SPRING color
   -"Activity": see SUMMER color
   -"Mod Black": see BLACK color
   -"Mod Pink": see PINK color
   -"Mod Cream": see CREAM color
   -"Mod Lilac": see LILAC color
   -"Mod Plague": see PLAGUE color
   -"Mod Fallow": see FALLOW color
   -"Mod Sky": see SKY color
   -"Mod Spore": see SPORE color
   -"Fine-tune Spore": see SPORE color

7. Reaction genes (Genetic Laboratory): 
   All segments can react on colors by touching,
   but ONLY if an organism has "TEAL" segments (or with the EYE segment, if it has "CYAN" segments)
   -"0" = Ignores (no reaction)
   -"1"= Organism stands still
   -"2"= Direction of movement: end to starting point of its touching segment (mostly flees)
   -"3"= Direction of movement: end point of touching segment to starting point of its first segment (flees)
   -"4" = Direction of movement: starting to end point of its touching segment (mostly attacks) 
   -"5" = Direction of movement: center of this organism to center of the other organism (attacks)
   -Notes: Special reactions to...
     -GREEN: Used for all photosynthetic segments except BARK
     -SILVER: Only SILVER consumer (else default reactions are in use, see below)
     -SPIKE: Only sharp point of SPIKE uses SPIKE
      else (SPIKE line): GREEN for plants, (default)-CONSUMER for enhanced SPIKE and BLUE for the rest
     -WHITE: Only White plants without plague segments (and BROKEN color)
     -VIRUS: Only WHITE non plants and non consumers without plague, frozen or auburn segments
     -PLAGUE: Used for WHITE and PLAGUE plants, as long as the organism has PLAGUE segments
     -(default)-VIRUS: Used for all other WHITE and PLAGUE organisms (mostly small plague viruses)
     -MINT: Used for MINT and LAVENDER
     -MAGENTA: Used for MAGENTA and ROSE
     -DEFAULT: All other colors for organims that are not plants or consumers
     -(default)-CONSUMER: All other colors for organisms that are consumers
     -(default)-PLANT: All other colors for organisms that are plants but not consumers
     -FROZEN: used for FROZEN and DEADBARK color
     -BEIGE: Used for BEIGE and DARKFIRE color
     -Sick organisms (BEIGE, DARKFIRE, WILTED, NAVY, FROZEN, DEADBARK, BROKEN, DARKOLIVE, non point SPIKE)
      don´t use normal reactions on colors, but SICK (last column) against all colors.
     -If an organism encounters a friendly family member or another social
      organism with ROSE segments, it will use FRIEND on all colors.

8. Branching (Genetic Laboratory):
   -Segments can branch out now (like in trees).
   -A gene can only branch at a position before or at its normal place, 
    so if you set Branch > Gene, you cannot place the organism into the world. 
   -If branch = -1, there is no branch.

9. Segment effectivity changes:
   -Photosynthesis is more effective for organisms with lower symmetries and number of genes.
     -also used for PURPLE methanotrophy
     -Exact formula: 
       -for 8-symmetric organisms:
        ((1961 + (6000 / (number of genes + 2)) + (6315 / symmetry)) * 0.0006) * segment length
       -for 1 to 7-symmetric organisms: 
        ((1961.329 + (6000 / (number of genes + 2)) + (6315 / symmetry)) * 0.0006) * segment length
   -Photosynthesis is less effective for organisms with lower (1-7) symmetries at low CO2 levels.
     -not used for PURPLE methanotropy
     -threshold = "700 + (1200 / (symmetry + 1))" for symmetry 1-4, 940 for 5, and 870 for symmetry 6-7
     -if "randomly chosen value between 0 and threshold" >= CO2 levels, photosynthesis fails this frame
   -Effectivity of consuming segments and LILAC and SPIKE uses roots now.
     -Exact formula: sqrt(segment_length)
     -Notes: Large consuming segments are less and less effective per length. 
      Of course they are still more effective than smaller segments.
      Default value for "Obtained energy": 
      2.0 instead of 0.5 because of this change

10. The program now knows, how to classify organisms:
   -if it has RED, FIRE, ORANGE, MAROON, PINK (Mod Pink: yes) or CREAM segments, it is a consumer
   -if it has unmodified PINK segments, it is a fungus
   -if it has photosynthetic or methanotrophic segments, it is a plant
   -if it has LILAC, SPIKE or GRAY segments, it is a killer
   -enhanced: has DARK GRAY segments
   -Mirrored 3-symmetric organisms are often treated like 2-symmetric ones for the total amount of color
    length (handicap to help bilateral organisms, which are more common in nature and look better)
   -Unmirrored 3-symmetric organisms are often treated as if they have a symmetry of 2.5 for the total
    amount of color length (half of the handicap)
        
11. 46 colors (39 new ones) and altered the function of some of the old colors:
    -"enhanced" = has DARKGRAY segments
    -effectivity for photosynthetic/methanotrophic segments and DARK GRAY (used for enhanced FOREST)
    -costs for the rest

-DARKGRAY (Enhancement):
  -enhances other segments (see "enhanced" for other colors)
  -DARKGRAY effectivity is used for FOREST enhancement

-GREEN (standard Photosynthesis): 
  -no changes

-FOREST (Colony photosynthesis): [also used on friends]
  -if an organism with FOREST segments touches another plant, photosynthesis effectivity is improved:
    -added FOREST photosynthesis = "x" * "+ Forest effectivity if not alone" * "Forest effectivity":
      -normal segment touches normal segment:                           "x" = 0.28
      -normal segment touches BARK segment:                             "x" = 0.28
      -normal segment touches photosynthetic segment:                   "x" = 0.38
      -normal segment touches FOREST segment:                           "x" = 0.48
      -BARK segment touches BARK segment:                               "x" = 0.38
      -BARK segment touches photosynthetic segment:                     "x" = 0.48
      -BARK segment touches FOREST segment:                             "x" = 0.58
      -photosynthetic segment touches photosynthetic segment:           "x" = 0.78
      -photosynthetic segment touches FOREST segment:                   "x" = 0.88
      -FOREST segment touches FOREST segment:                           "x" = 0.98
      -if it is the first touch with another plant in a frame "x" = 0.03 is added to the total
    -DARKGRAY segment of a consumer touches non enhanced organism: 0.5 * "DARKGRAY" * "FOREST" effectivity
    -DARKGRAY segment of a killer touches non enhanced organism:   0.5 * "DARKGRAY" * "FOREST" effectivity
    -DARKGRAY segment of all other plants touches non enhanced organism: "DARKGRAY" * "FOREST" effectivity
    -DARKGRAY segment touches enhanced organism: no extra photosynthesis
  -Notes: 
    -FOREST added photosynthesis depends on the basis FOREST photosynthesis effectivity now, 
     because of very useful performance improvements, which make the simulation run faster.
     Therefore you need to have a very high value for "+ Forest effectivity if not alone",
     if your value for "Forest effectivity" is low.
    -does not work with methanotrophs without photosynthetic segments

-SPRING (Photosynthesis and Rotation):
  -"Clockwise"=Yes: Organism rotates clockwise
  -"Clockwise"=No: Organism rotates counter-clockwise

-SUMMER (Photosynthesis and seasons):
 -"Activity" "0-2" active for 2 seasons (time units) and inactive (no photosynthesis) for one season
 -Inactivity is true in different seasons for each of them and the segment turns into color WINTER
 -WINTER does not photosynthesize

-LIME (Solo photosynthesis):
 -If alone (more effective): Photosynthesis = "Lime effectivity"
 -If crowded (less effective): Photosynthesis = "Lime effectivity if not alone" * "Lime effectivity"
 -LIME crowded photosynthesis depends on the basis LIME photosynthesis effectivity now, 
  because of very useful performance improvements, which make the simulation run faster.
 -You can actually make LIME more effective if crowded, 
  if you set "Lime effectivity if not alone" > "1.0", but FOREST already does this... 

-LEAF (Undisturbed photosynthesis):
 -Only photosynthesizes, if the organism is not shown in color
 -It will also be shown in DARKGREEN (also no photosynthesis) thereafter, 
  if it was shown in an "getting attacked color" before

-C4PLANT (small segment photosynthesis):
 -Comparably more effective, if the segment is smaller, and less effective, if it is larger
 -Exact formula = C4PLANT effectivity * (10 + segment length)
 -Reworked old C4PLANT, because it was able to diminish CO2 levels,
  and that made it the only effective photosynthetic color, killing plant color diversity
 -If the organism has only C4PLANT photosynthetic segments, no PURPLE and not a consumer:
  -It can dodge like passive TEAL
  -Formula: C4PLANT effectivity * (11 + segment length), if it can dodge
  -No dodging and no bonus effectivity, if it has BLACK, BLUE, OCHRE, OLIVE or FALLOW segments however
  -No bonus effectivity, if it has BLUE or CYAN spores
  -with INDIGO: force infections to use parent reproduction energy
   instead of virus reproduction energy, if the latter is higher (good for small plants)
  -with BLOND: cheaper BLOND costs for non-plants are used
  -with AUBURN: immune vs infectious plants
  -with FLOWER: immune vs FALLOW
  -with GOLD: GOLD maintenance is 0.1 * normal maintenance (instead of 0.126 * normal)
  -enhanced: allows dodging vs SKY
  
-JADE (Small organism photosynthesis and anti viral abilities)
 -if viral organisms attack, JADE will turn into DARKJADE, then DARKGREEN
 -and other photosynthetic segments except BARK will directly turn into DARKGREEN, 
  if the organism has jade segments
 -DARKGREEN can get infected, JADE and DARKJADE can not
 -DARKJADE is photosynthetically active, DARKGREEN is not
 -if VIOLET or modified SKY attacks, JADE turns into DARKJADE, then DARKGREEN
 -if GRAY attacks, JADE turns into DARKJADE, then DARKGREEN, if the organism has MAGENTA segments
 -DARKGREEN can get poisoned by VIOLET, and frozen by SKY (if the organism has no MAGENTA segments)
 -DARKJADE and DARKGREEN regenerate, faster for organisms with low symmetry (but symmetry 1 is like 2)
 -plants with JADE, that are not consumers force infections to use parent reproduction energy
  instead of virus reproduction energy, if the latter is higher (good for small plants)
 -if the organism has MINT segments, an attack by PLAGUE (or WHITE with PLAGUE) segments on photosynthetic
  segments except BARK will get the other organisms WHITE, PLAGUE and CORAL segments destroyed
 -JADE segments make photosynthetic segments immune vs FALLOW
  
-GRASS (difficult to consume and photosynthesis)
 -consumer only feed from it with halfed efficiency (shown in wilted color instead of yellow)
 -SPIKE and LILAC energy drain is also halved

-BARK (Photosynthesis and Protection):
 -if another organism touches the BARK segment aggressively, BARK lignifies (= OLDBARK)
 -lignified OLDBARK protects the organism, but photosynthesis is disabled
 -enhanced:
  -BARK organism will show in Color=BROKEN
  -attacker can only absorb from OLDBARK, if the OLDBARK organism is already shown in color,
   so it might have to wait one frame to absorb for 0.01 * "normal" segment effectivity

-PURPLE (Methanotrophy):
 -gets energy from CH4 in the atmosphere every 8 frames (default: 50% effectivity of photosynthesis)
 -methanotrophs without photosynthetic segments, that are not consumers force infections to use
  parent reproduction energy instead of virus reproduction energy, if the latter is higher
 -methanotrophy is only 0.55 * normal effectivity, if it has photosynthetic segments too
 -Only 0.01 * segment maintenance for PURPLE
 -enhanced and not a killer: normal methanotrophy effectivity is used each frame to get energy,
  if touching a dead organism with a DARKGRAY or PURPLE segment
  
-RED (Carnivore): 
  -feeds on other consumers except CREAM
  -feeds on SILVER, if SILVER is a consumer (see SILVER)
  -feeds on SPIKE, if the other organism is enhanced
  -with LAVENDER segments: invulnerable against PLAGUE, FALLOW and enhanced OCHRE
  -enhanced (0.25 * normal energy absorbing effectivity):
    -feeds on CREAM
    -feeds on LILAC, SPIKEPOINT, GRAY, if the other organism is a consumer
    -invulnerable against LILAC, SPIKEPOINT, and GRAY
    -normal energy absorbing effectivity vs enhanced GRAY

-FIRE (Generalist): [Notes: between Carnivore and Omnivore] 
  -segment energy absorbing effectivity: 
    -"normal" against organisms, that are consumers (shown Color=FIRE)
    -also "normal" against BEIGE segments
    -also "normal" against frozen plants, if it has SKY segments
    -also "normal" against modified PINK with GRAY segments  
    -(0.25 * "normal") against MAROON, PINK, CREAM, not enhanced SPIKE,
     and the rest (shown Color=DARKFIRE)
  -regenerates poisoned segment (turns DARKFIRE) vs VIOLET consumers
  -enhanced: 
    -now feeds on BROWN, WILTED and version 4 spores
    -but cannot regenerate vs VIOLET consumers anymore and cannot feed on VIOLET non-consumers
    -but cannot attack unmodified SKY anymore

-ORANGE (Omnivore):
  -feeds on most segments except RED, MAROON, non plant WHITE (virus) and most protected segments
  -absorbing effectivity is 0.5 * "normal" vs CORAL non consumers
  -enhanced: feeds on FROZEN and DEADBARK and more effective vs FALLOW version 3 and 4

-MAROON (Herbivore): 
  -feeds on all photosynthetic segments
  -feeds on protected segments of plants
  -feeds on WHITE segments of plants
  -only 0.2 * maintenance costs
  -energy drain for enhanced BLUE and OCHRE vs MAROON is halfed
  -MAROON with MAGENTA is immune for one frame vs VIOLET consumers, unmodified non-enhanced SKY
   and GRAY consumers, if not shown in color
  -enhanced: 
    -feeds on many more defenseless segments, SPIKEPOINT and WILTED (shown color=AUBURN)
    -attacks SKY, what allows MAROON to feed on DEEPSKY the next frame
    -enhanced BLUE and OCHRE have no effect

-PINK (Decomposer):
   -feeds on PINK, CREAM, WHITE, PLAGUE, CORAL and all weakened segments
   -only 0.2 * maintenance costs except if it has gray segments
   -"Mod Pink"=Yes:
     -PINK with GRAY can feed on BROWN and is not immune vs infections
     -only 0.5 * effectivity vs CORAL (except CORAL consumers)
     -only 0.5 effectivity vs DARKFIRE, if that segment was a FIRE segment
     -enhanced: feeds on BARK (includes plant spores)
   -"Mod Pink"=No: 
     -immune against infections 
     -only 0.25 * effectivity (shown Color=DARKFIRE) vs PINK
     -only 0.25 * effectivity vs weakened segments (but normal vs ICE and BLOND plants) of plants
     -only 0.25 * effectivity vs DARKFIRE (except if the other organism is not a consumer or plant)
     -with BLOND segments (but without blue and cyan spores): does not need to grow up to reproduce  
     -enhanced: feeds on BARK with 0.25 * effectivity (but normal vs BARK with BLOND segments)
     -PINK with GRAY can´t feed on BROWN
   -with FALLOW segments: absorbs a still birth created by "Mod Fallow"=3 completely in one attack
   -PINK feeding creates CH4 instead of CO2 

-CREAM (Parasite):
  -segment energy absorbing effectivity = (0.1 * "normal")
  -mostly immune vs infections if it is no plant, else only immune vs WHITE plants
  -completely immune vs WHITE and FRUIT with INDIGO segments
  -enhanced:
    -"Mod Cream"=1:
      -feeds on consumers except SILVER, PINK and CREAM
    -"Mod Cream"=2:
      -feeds on CREAM, PINK, CORAL and WHITE viruses
      -absorbing effectivity for PINK, FIRE and enhanced RED against CREAM is reduced to 0.1
      -CREAM plants immune vs enhanced WHITE plants
      -CREAM non-plants immune vs enhanced WHITE       
    -"Mod Cream"=3: 
      -feeds on protected segments, mostly on plants, 
       except BLUE with LAVENDER segments and BLUE non-plants

-SILVER (Experience):
  -if the organism has more total infections than the other organism:
    -it infects nearly all other segments, including protected ones that WHITE does not infect
    -it needs to have WHITE (or CORAL) segments to get at least one infection
    -uses normal SILVER costs
    -shown Color=SILVER, if it infects
  -if it has more than 0 total kills (and is a consumer or a killer) or is enhanced:
    -segment energy absorbing effectivity formula:
     ((12+total kills)/(12+other organisms total kills))*segment length
    -feeds on SPIKEPOINT if it has more total kills
    -if a non-consuming killer (also PLAGUE without WHITE) kills, 
     it becomes a consumer when SILVER touches a segment it can feed on
    -uses SILVER consumer costs
    -shown Color=GOLD, if it consumes
  -extra childs for more total children, if it is a consumer or virus:
    >=0   total children = 1 child
    >=1   total children = 2 childs 
    >=9   total children = 3 childs 
    >=36  total children = 4 childs 
    >=100  total children = 5 childs 
    >=225  total children = 6 childs 
    >=441  total children = 7 childs
    >=784 total children = 8 childs
  -extra child for more total children, if it is not a consumer and not a virus:
    >=0   total children = 2 childs
    >=2   total children = 3 childs 
    >=5   total children = 4 childs 
    >=9  total children = 5 childs 
    >=14  total children = 6 childs 
    >=20  total children = 7 childs 
    >=27  total children = 8 childs

-SPIKE (weaken with segment point):
 -segment energy draining effectivity = 5 * "normal" absorbing effectivity
 -SPIKEPOINT cannot be hurt by most segments
 -SPIKE line does not drain any segments 
 -SPIKE line has no defense for all SPIKE plants and enhanced SPIKE
 -SPIKE line for non-plants and non-enhanced SPIKE organisms is mostly invulnerable like SPIKE point
 -SPIKEPOINT for non-plants and non-enhanced SPIKE organisms does not drain non-consumer plants,
  which is a buff because you don´t want to kill your food
 -SPIKEPOINT of non-plants and non-enhanced SPIKE organisms only drains MAROON
  for 0.8 * "normal" absorbing effectivity, which is a buff for MAROON-SPIKE consumers
 -if it has LAVENDER segments SPIKE line is immune vs CREAM in all cases
 -non-plant/consumer viruses drain CORAL and do not drain non-CORAL viruses
 -enhanced: 
   -consumes for 0.8 * "normal" absorbing effectivity
   -no energy drain
   -will be infected by feeding on FRUIT, but immune with MINT
   -uses "Spike consumer costs"

-LILAC (Weaken):
  -segment energy draining effectivity = 10 * "normal" absorbing effectivity
  -has to recharge after one attack (Color=DARKLILAC)
  -"Mod Lilac"=No: 
    -doesn´t drain non consumers harmless segments and WHITE, without PLAGUE or FALLOW segments
    -drains SPIKEPOINT of enhanced consumers
  -"Mod Lilac"=Yes:
    -does drain nearly all segments except BLUE and OLIVE
    -drains SPIKEPOINT of plants
  -enhanced: doesn´t need to recharge

-GRAY (Killer): 
  -kills the other organism, which changes its color to BROWN
  -against OCHRE: kills all plants
  -against OLIVE: GRAY segment gets destroyed, but OLIVE changes its color to DARKOLIVE
  -against DARKOLIVE: GRAY segment gets destroyed, but DARKOLIVE changes its color to NAVY
  -only kills SILVER if it has as much or more total kills than SILVER
  -attacks (forces shield) of modified SKY and of all other SKY plants
  -non-plant/consumer viruses kill CORAL
  -organisms with MAGENTA will survive once against GRAY but all MAGENTA segments change into DARKFIRE
  -an attacked VIOLET segment of a consumer with MAGENTA will change into DARKFIRE too
  -consumers with MAGENTA and GRAY (or if VIOLET is touched) will not survive once
  -MAGENTA protects from GRAY, except if MAGENTA has GRAY segments
  -enhanced: 
   -kills plant and infectious FALLOW, and JADE with MAGENTA
   -kills BARK, PINK and CORAL, if GRAY isn´t a consumer
   -FALLOW, BARK and PINK with MAGENTA can use the MAGENTA shield to survive this
 
 -VIOLET (Poison):
  -poisons other segments and makes them useless
  -segment it touches changes color to WILTED, if the other organism is a plant, otherwise BEIGE
  -Non consumers are immune vs WHITE plant infections (not immune vs other viruses)
  -attacks (forces shield) of modified SKY and of all other SKY plants
  -only 0.2 * maintenance costs for organisms, that are neither consumers nor plants
  -special against:
    -FIRE: enhanced non-consumers without WHITE segments cannot be fed on by FIRE 
    -FIRE: poisons, but only non-consumers poison permanently (else turns DARKFIRE)
    -CREAM: poisons, but only non-consumers and non-infectious poison permanently (else turns DARKFIRE)
    -WHITE: poisons, but VIOLET consumers don´t poison non plant and non consumer WHITE segments
    -VIOLET: poisons, but VIOLET consumers don´t poison non plant and non consumer VIOLET segments
    -SILVER: poisons, but VIOLET consumers must have as much or more kills
    -SPIKE: poisons all plants and enhanced SPIKE, else enhanced consumers and everyone else poison 
    -LILAC: enhanced consumers and everyone else poison
    -FALLOW: non-consumers and non-infectious poison (both needs to be true)
    -PLAGUE: all PLAGUE with WHITE segments are poisoned, non-consumer VIOLET poisons all PLAGUE
    -OLIVE: VIOLET segment gets destroyed but OLIVE changes color to DARKOLIVE
    -DARKOLIVE: VIOLET segment gets destroyed but DARKOLIVE changes color to NAVY

-OLIVE (Defense cracker):
  -destroys all SKY and OCHRE plants (segment it touches changes color to NAVY)
  -destroys BLUE plants, if it has no WHITE segments or is not a plant
   (segment it touches changes color to NAVY)
  -destroys LILAC, SPIKE, SPIKEPOINT, GRAY and VIOLET (segment it touches changes color to BROKEN)
  -non-consumers destroy FALLOW of plants, if not infectious or not a plant (color change to BROKEN)
  -gets weakened against GRAY and VIOLET (own segment changes color to DARKOLIVE), if without MAGENTA
  -regenerates fast if weakened, but DARKOLIVE will change color to NAVY, if touched by GRAY or VIOLET
  -destroys OLIVE plants, if it is not a plant, else weakens OLIVE plants
  -destroys DARKOLIVE plants, if it is not a plant
  -plant OLIVE segments weaken other plant OLIVE segments (only one changes color to DARKOLIVE now),
   but not if the plant has WHITE segments, and the other does not
  -destroys BARK if it is not a consumer and not a plant, or if BARK is a consumer or enhanced
   (segment it touches changes color to DEADBARK)
  -OLIVE can only be infected by non plant viruses or enhanced WHITE
  -OLIVE non-plants without WHITE segments or organisms, 
   that are enhanced or have CORAL segments destroy BLUE spores
  -0.45 * segment maintenance for non-plant OLIVE
  -enhanced: 
    -destroys all BLUE, BARK and OCHRE and all FALLOW of plants
    -OLIVE plants without WHITE segments destroy OLIVE and DARKOLIVE of plants with WHITE segments
    -OLIVE with WHITE segments destroys BARK plant spores

-SKY (Freezer and Frost shield):
  -freezes (disables) all movement segments (shown Color=SKY)
  -does this by touching an arbitrary segment except BLUE, CORAL, FALLOW, SPIKEPOINT and OLIVE
  -these disabled segments colors are FROZEN or DEADBARK (if it was BARK)
  -protects itself with a frost shield against attacks (shown Color=DEEPSKY)
  -DEEPSKY however can be attacked by PINK, SILVER and MAROON, but these cannot force the frost shield
  -regenerates quickly again from shielding to freezing
  -consumers with SKY segments can feed on FROZEN and DEADBARK segments
  -freezes moving FRUIT (Mod spore 1, also disables them)
  -"Mod Sky"=Yes:  
    -freezes (disables) all photosynthetic segments (shown Color=SKY)
    -freezes CYAN moving spores (Mod spore 10-12)
    -disables modified SKY segments, or all SKY, if not a plant (color changes to NAVY)
    -plants cannot dodge SKY, if shown in color (makes SKY good at hunting dodging plants)
    -other organisms WHITE forces the frost shield, if it is not frozen or if it has MAGENTA segments
    -enhanced: 
      -disables all SKY segments (color changes to NAVY)
      -JADE and DARKJADE are frozen directly
  -"Mod Sky"=No:
    -does not freeze photosynthetic segments and unmodified SKY
    -only non-consumers and enhanced organisms freeze MAROON (helps MAROON to not freeze each other)
    -CORAL and non-plant and non-infectious FALLOW can be touched to freeze an organism
    -freezes CYAN moving spores (Mod spore 10-12), if not a plant
    -freezes CREAM spores (still able to consume)
    -DEEPSKY protects from modified SKY, but "12 * SKY costs" are used each frame (not only to activate)
    -plant OCHRE cannot push unmodified SKY, but still uses OCHRE costs
    -plants cannot dodge with TEAL segments vs SKY at all
    -WHITE only forces the frost shield, if it is a plant or a consumer and also not frozen
     (SKY can be forced if WHITE has MAGENTA segments however) or it is an enhanced virus without
     killer segments and SKY is a plant and without MINT segments
    -non plants and non consumers (= small viruses) do not attack each other
    -0.1 * segment maintenance for non-plant SKY
    -other organisms MAGENTA protects aggressive segments (except VIOLET, SPIKE, GRAY and FALLOW)
     and the altruistic segments from getting frozen, but non-plants and enhanced organisms
     will freeze them, except MAGENTA itself which can create a MAGENTA shield
    

-BLUE (Shield):
  -no changes, but 0.1 * segment maintenance for non-plant BLUE
  -enhanced: -attacking organisms lose energy, 0.5 * normal absorbing effectivity (only 0.25 for MAROON)
             -not vs FALLOW or enhanced OCHRE

-OCHRE (Pushing): 
  -Organism pushes other organisms away, stronger with longer OCHRE segments
  -doesn´t work against OLIVE and unmodified SKY
  -offers protection against many attacks
  -costs are 0.01 * normal costs for non-plants
  -enhanced:
    -other organism loses energy depending on how much it was pushed,
     but halved for MAROON and quartered for enhanced MAROON
    -other organisms energy loss is divided by 250, if its own OCHRE segment is pushed 
    -no energy drain vs BLUE, CREAM, CORAL and unmodified SKY, 

-FALLOW (Inhibit reproduction):
 -other organism cannot reproduce for "normal delay + (10 * segment length)" frames (shown Color=FLOWER)
 -but if it has infected the other organism, it can remove the inhibition, so that the virus can break out
 -protected vs many effects and vs infections
 -attacks FALLOW, if FALLOW is a killer or has BLOND segments
 -does not attack MINT, OLIVE, FLOWER and DARKGRAY
 -inhibits hatching of all version 3 and 4 spores
 -non-plants and "Mod Fallow"=1 ignore LAVENDER protection of these spores
 -delays hatching of version 6 spores
 -FALLOW without WHITE segments or plant segments ignores the lavender shield vs spores
 -0.1 * absorption efficiency vs FALLOW for not enhanced ORANGE and not enhanced FIRE
 -0.1 * absorption efficiency vs FALLOW for SPIKE (FALLOW is invulnerable against enhanced SPIKE)
 -0.01 * absorption efficiency vs FALLOW without plant segments and WHITE for all ORANGE and FIRE
  (shown Color=BROKEN)
 -"Mod Fallow"=1: 
   -0.1 * segment maintenance for FALLOW   
   -FALLOW abilities only used vs organisms with SPORE (only version 1-6) segments
   -used vs RED segments (of SPORE organisms)
   -if affected the SPORE organism always reproduces its virus (in all reproduction attempts)
   -if affected the SPORE organism can create its own child only after one failed reproduction attempt
    during which it was not infected
   -attacks photosynthetic segments of SPORE organisms even if protected by JADE
 -"Mod Fallow"=2: 
   -0.1 * segment maintenance for FALLOW
   -attacks unmodified PINK, and PINK can be infected if its time to reproduce is over normal delay frames
   -but unmodified PINK with MINT segments cannot be attacked by FALLOW plants, although all other FALLOW
   -but unmodified PINK with FLOWER segments can never be infected later
   -with WHITE segments: no inhibition of version 3 consumer spores and all version 4 spores
 -"Mod Fallow"=3:
   -0.1 * segment maintenance for FALLOW
   -inhibition is "normal delay + (1 * segment length)"
   -other organisms children will be born dead (but infections will be alive)
   -other organisms will have alive children again after reproducing "(FALLOW segment length/2)+1" times
    (non consumers will create a normal child after one failed reproduction attempt)
   -stillbirths apparent age will be shown as double the maximum age (so that you can differentiate it)
   -stillbirths do not work vs organisms with FLOWER segments
   -with WHITE segments: -inhibition is "normal delay" and one stillbirth only for all victims
 -"Mod Fallow"=4:
   -0.2 * segment maintenance for FALLOW
   -inhibition is "normal delay + (5 * segment length)"
   -destroys all YELLOW, BLOND, AUBURN, INDIGO and SPORE (only "Mod Spore" 1-6) segments
   -if the other organism has MINT segments, only touching one segment directly will get it destroyed
   -with WHITE segments: -normal segment maintenance and normal absorption efficiency vs FALLOW
 -enhanced organisms without WHITE segments:
   -victims lavender shield energy is depleted faster for 2220 shield energy per frame 
 -enhanced (if the other organism has no LAVENDER segments), or non plants without WHITE segments
  also inhibit RED reproduction
 -non plant FALLOW has always 0.01 * segment maintenance
 -non plant FALLOW always attacks unmodified PINK, but reproductive segments are never destroyed
 -FALLOW consumers (but enhanced do) only inhibit organisms with FALLOW segments of the same
  "Mod Fallow" version, that are infectious (this is a buff, because they don´t hurt each other)

-SPORE (create different spores):
 -Organisms create spores, that are completely in one color and only grow to the second growth stage
 -SPORE blocks infections in general for "Mod Spore" 7-12, and if it isn´t infected at all for 1-2
 -SPORE blocks forcing by PLAGUE for  "Mod Spore" 7-12, and else, if it isn´t a consumer
 -SPORE 1-3, and 4-6 for organisms with BLOND segments receive energy: "spore segment length/symmetry"
 -SPORE 4-6 receive energy: "normal reproduce energy * 0.025 * spore segment length/symmetry"
 -SPORE 7-12 receive the normal energy, SPORE production depends on the SPORE organism, not the parent
 -Only 0.01 * segment maintenance for SPORE
 -SPORE 1-6:
   -If infected, it will create a virus in 3 of 14 to 18 (or 15 to 19 for plants) reproduction attempts:
   -3/14 (+1 for non consuming plants) for 1-symmetric organisms
   -3/15 (+1 for non consuming plants) for 2/3-symmetric organisms
   -3/16 (+1 for non consuming plants) for 4/5-symmetric organisms
   -3/17 (+1 for non consuming plants) for 6/7-symmetric organisms
   -3/18 (+1 for non consuming plants) for 8-symmetric organisms
   -SPORE 3-6 neither produces a virus (nor a spore child however), even if it is one of these 3/14-16
    reproduction attempts (shown Color=SPORE), if the virus infected the organism at the SPORE segment
    before, in 3 of 4 attempts for symmetry 8, 2 of 3 for symmetry 4-7, and 1 of 2 for symmetry 1-3,
    else the virus is finally created 
   -SPORE 1-2 will remove the infection immediately, even if the virus was not created
   -Else infections are only removed, if the virus is created
   -Organisms will create a spore child in all cases, never a non-spore child
   -If forced by PLAGUE with WHITE segments and a consumer, creates a virus in: 
     -3 of (14 to 18, see above) - 10 reproduction attempts, if PLAGUE is modified
     -else 3 of "(120/infection virus symmetry) + (14 to 18, see above) - 25" reproduction attempts
     -if infection virus symmetry is 2: "(120/3) + (14 to 18, see above) - 25" reproduction attempts
   -If forced by PLAGUE with WHITE segments and not a consumer, creates a virus in: 
     -3 of "(120/infection virus symmetry) + (14 to 18, see above) - 25" reproduction attempts
     -if infection virus symmetry is 2: "(120/3) + (14 to 18, see above) - 25" reproduction attempts
   -PLAGUE without WHITE and YELLOW viruses (see WHITE) will force a virus in all reproduction attempts
   -LAVENDER shield, if applicable, will start with 200 energy (full for non-consumers and non-plants) 
 -SPORE 1-2 reproduce early like BLOND, early reproduction energy is "40 + 1 * segments"
 -Mod spore:
   -1: 
     -Spore moves around until finding a plant, then integrates itself, "feeds" and infects the plant
     -Energy the infected virus receives at birth depends on the starting energy of the spore
     -infects DEEPSKY, BARK, OLDBARK, all OLIVE, OCHRE and SPIKE, but the virus will get less energy
     -does not infect BLUE, VIOLET, CORAL, MINT, SPIKEPOINT or consuming segments
     -integrates into INDIGO (if INDIGO is a plant), but does not infect (only feeds INDIGO)
     -plant segments (except BARK) are not infected, if the potential victim has MINT segments,
      and the spore is destroyed by MINT
     -other organisms delay to reproduce is set to 0
     -organisms, that also can feed on WHITE non-consumers and non-plants can feed on it
     -never hatches
     -reproduction delay for non-consumers and non-plants is maximized after being born 
   -2: 
     -Spore is a fruit, that needs to be eaten to infect other organisms.
     -Energy the infected virus receives at birth depends on the starting energy of the spore
     -Life expectancy of the spore depends on its starting energy (-1 for consumer spores)
     -infects unmodified PINK without INDIGO segments, but the virus will get less energy
     -PINK with BLOND segments (even with MINT segments) is treated like normal consumers
     -spores do not infect CREAM, but can be eaten
     -ORANGE absorption efficiency vs non-consumer fruits is only 0.1
     -FIRE absorption efficiency is always 0.1
     -never hatches and no maintenance
     -reproduction delay for non-consumers and non-plants is maximized after being born 
   -3: 
     -Seed spore, that will hatch after "104 - "length of spore segments/symmetry" frames
     -Plant spores (including spores by non-consumers) are eaten by MAROON (spore color = BARK) 
     -Only 0.5 * absorption efficiency for MAROON against spores of non-consumers
     -Only 0.25 * absorption efficiency for FIRE against consumer spores
     -MAROON already feeds on BARK spores (not only OLDBARK) of consumers
     -Non-Plant consumer spores are eaten by all other consumers (spore color = VISION)
     -If "Disperse children"=Yes:
      -the seeds starting speed is *2.0 for moving organisms
      -the seeds starting speed is *2.0 for stationary organisms, that are both plants and consumers
      -the seeds starting speed is *3.0 for all other stationary organisms
     -No maintenance
   -4:
     -Egg spore, that will hatch after "115/116 - "length of spore segments/symmetry" frames
     -Non consumers hatch after "104 - "length of spore segments/symmetry" frames
     -They are eaten by PINK and enhanced FIRE
     -If the egg is attacked, eggs of consumers break and cannot hatch anymore
     -spore color is really BROWN, but will be shown in SPORE
     -No maintenance
   -5:
     -CREAM larva spores, that move around slowly, and hatches at 1/2 reproduction energy
     -enhancement for CREAM is off, but:
       -"Mod Cream"=1: feeds on BROWN (including spore 4)
       -"Mod Cream"=2: feeds on PINK and PINK has 0.1 * absorption effectivity against CREAM
       -"Mod Cream"=3: feeds on OLDBARK, attacks unmodified SKY and feeds on all DEEPSKY
     -will not be infected feeding on SPORE 2
     -grown up SPORE-5 is classified as a fungus, if neither a consumer nor a plant
     -reproduction delay for non-consumers and non-plants is maximized after hatching,
      and after birthing a child even with BLOND segments
     -life expectancy is reduced by 1 time unit in comparison to the grown organism
   -6:
     -photosynthetic (or methanotrophic) Spore hatches at 1/2 reproduction energy
     -specific spore color abilities are not in effect, except if stated otherwise
     -JADE ability is always off for all consumers and BLOND organisms, and always on
      for other non-plants, and on for plants if they have JADE segments, but it cannot regenerate
     -Methanotrophy is used every 8th frame only (like PURPLE itself)
     -Non-plants and Non-consumers: methanotrophy = 22 * mass (spore color = PURPLE)
     -Consumers without plant segments: photosynthesis = 7 * mass (spore color = SPRING))
     -Moving consumers with PURPLE segments: methanotrophy = 60 * mass (spore color = PURPLE)
     -Moving consumers with plant segments: photosynthesis = 7.5 * mass (spore color = C4)
     -Not moving consumers with plant segments: photosynthesis = 8 * mass (spore color = LEAF)
     -Plants with PURPLE segments: methanotrophy = 120 * mass (spore color = PURPLE)
     -Plants with BLACK segments: photosynthesis = 12 * mass (spore color = WINTER)
     -Plants with FALLOW or killer segments: photosynthesis = 15 * mass (spore color = SUMMER)
     -LIME plants: photosynthesis = 15 * mass if not alone, else 20 * mass (spore color = LIME)
     -FOREST plants: photosynthesis = 18 * mass, plus colony photosynthesis (spore color = FOREST)
     -Enhanced plants: photosynthesis = 19 * mass (spore color = GRASS, and GRASS is in effect)
     -JADE plants without BLOND segments: = 19 * mass (spore color = JADE, see above)
     -All other plants: = 19 * mass (spore color = GREEN)
     -Spores of plants or consumers with BLOND or GOLD segments (or affected by FALLOW version 1)
      will spawn a virus instead, if infected and trying to hatch
     -reproduction delay for non-consumers and non-plants is maximized after hatching,
      and after birthing a child even with BLOND segments   
   -7-9:
     -BLUE spore dormant for "((length of spore segments * 10)³)/400 frames
     -spore 7 does not hatch, when touching specific colors, see "Fine-tune spore"
     -If the organism has nearly no energy left, is very small and not attacked, 
      it can sporify itself (has to wait until not shown in color with WHITE and BLOND segments)
     -Can create exactly one child spore just before death of old age, if reproduction energy > 1/2,
      and it is fully grown (reproduce energy = energy + (16 + 3 * symmetry)
     -Needs to grow once after hatching to sporify itself again
     -Delay to reproduce for the organism: -6
     -Delay for SPORE hatching is a maximum of 20, only if near another organism, else not used
     -No maintenance
   -10-12:
     -CYAN spore moving around for "((length of spore segments * 10)²)/40 frames
     -real SPORE color is also BLUE, but shown color is CYAN
     -spore 10 does not hatch, when touching specific colors, see "Fine-tune spore"
     -If the organism has nearly no energy left, is very small and not attacked, 
      it can sporify itself, if it has no BLOND segments
     -Can create exactly one child spore just before death of old age, if reproduction energy > 1/2,
      and it is fully grown (reproduce energy = energy + (16 + 3 * symmetry)
     -Needs to grow once after hatching to sporify itself again
     -Delay to reproduce for the organism: -6
     -Delay for SPORE hatching is a maximum of 20, only if near another organism, else not used
 -Fine-tune spore (only for BLUE and CYAN spore):
   -1-20: creates a spore each time
   -20-30: creates a spore 1/2 of all reproductions
   -30-40: creates a spore 1/4 of all reproductions
   -40-50: creates a spore 1/8 of all reproductions
   -50-60: creates a spore 1/16 of all reproductions
   -60-70: never creates a spore in a reproductions (spores only used, when the organism has low energy)
   -Last digit used for hatching by touching another organisms segment ("X" is an arbitrary digit)
   -Spore 7 and 10 do never hatch touching another segment
   -X0: spore hatches, when it touches non-consumer and non-plant segments, but see exception
   -X1: spore hatches, when it touches RED 
   -X2: spore hatches, when it touches FIRE and consuming SILVER
   -X3: spore hatches, when it touches ORANGE and MAROON
   -X4: spore hatches, when it touches harmless unprotected consumer segments
   -X5: spore hatches, when it touches PINK
   -X6: spore hatches, when it touches plants with WHITE segments
   -X7: spore hatches, when it touches other plants harmless unprotected segments
   -X8: spore hatches, when it touches plants killer segments (but only unmodified LILAC)
   -X9: spore hatches, when it touches plants BLUE, OCHRE, FALLOW, all BARK, ICE and LIGHTBLUE segments
   -X9: hatches, if organism has MAGENTA segments, and it touches all OLIVE, all SKY and VIOLET segments
   -XX: spore hatches, if the organism has PINK segments, when it touches CREAM and BROWN
   -exception: spore of organism with WHITE or CORAL segments does not hatch, when touching CORAL   

-WHITE (Virus):
  -WHITE Plants use WHITE costs
  -Other viruses use "Non-plant white cost"
  -only infects organisms, that are consumers (but not unmodified PINK) or plants 
  -infects all segments except BLUE, SKY, BARK, OCHRE, FALLOW plants, MINT, SPIKEPOINT and LAVENDER
  -infects SPORE, if SPORE is already infected by another organism and "Mod Spore": 1-6
  -infects NAVY and OLIVE, if it is no plant
  -infects VIOLET, if it is no plant or the other organism is a consumer
  -infects CREAM, if it is no plant and the other organism is a plant
  -only infects SILVER if it has as much or more total infections, or if SILVER is enhanced
  -infects PLAGUE, if the PLAGUE organism has WHITE segments
  -attacks SKY, if it isn´t frozen or has MAGENTA segments
  -enhanced: 
    -infects all NAVY, and non killers also VIOLET, OLIVE plants, DEEPSKY, CREAM, SPIKEPOINT, ICE
     and DEADBARK segments
    -non plants/consumers infect FALLOW plants
    -if the other organism has MINT segments, enhanced infection will not work, 
     except vs CREAM, enhanced SPIKEPOINT, NAVY, ICE and DEADBARK
  -if an organism is not a consumer or plant (real VIRUS):
    -if it has YELLOW segments:
      -other organism cannot reproduce for number of "default delay" frames
      -if the other organism is infected and has enough energy to reproduce,
       it is forced to reproduce as many viruses at once as the virus would reproduce with YELLOW
      -also works vs version 6 spores, if they would be able to hatch (0.5 * reproduce energy)
      -only 0.1 * absorption efficiency vs non plant/consumer YELLOW for ORANGE, FIRE and enhanced SPIKE
    -if it has INDIGO segments:
      -INDIGO fake target is in effect (see INDIGO), 
       also in effect for own SILVER and PLAGUE color and vs enemy CORAL
    -if it has AUBURN segments:
      -infects unmodified PINK, and VIOLET and LIGHTBROWN of unmodified PINK organisms
      -vulnerable like a plant WHITE segment (vs ORANGE for example)
    -if it has MINT segments:
      -MINT does not destroy their WHITE segments, if the other virus has MINT segments too
    -if it has MAGENTA segments:
      -it can regenerate WHITE fast against MINT
      -immune vs non enhanced GRAY (use MAGENTA energy consumption)
    -if it has BLOND segments:
      -immediately reproduces (if it has enough energy), when born, and creates a virus cluster
      -LAVENDER shield, if applicable, will start with 0 energy
      -can not infect CORAL
    -if it has VIOLET segments:
      -VIOLET immune from predation by FIRE and 0.5 * absorption efficiency for ORANGE
      -VIOLET and WHITE of viruses is not attacked (except if it has CORAL segments)
      -Low maintenance = 0.05 * normal for VIOLET
      -Photosynthetic segments are not poisoned (not in the interest of the virus)

-PLAGUE (force virus reproduction of infected organisms):
  -other organism must reproduce a virus (no normal children), if it was infected before by this organism
  -cannot force BLUE, SKY, OLIVE (can DARKOLIVE), RED, CREAM, MINT, LAVENDER and CORAL
  -cannot force non-enhanced SPIKE
  -cannot force SPORE versions 7-12
  -forces SILVER if it has as much or more total infections, or if SILVER is enhanced
  -PLAGUE plants use PLAGUE costs
  -Other plague viruses use "Non-plant plague cost"
  -"Mod Plague"=Yes: only forces the reproduction of consumers
    -enhanced: forces RED and CREAM (not if these have LAVENDER segments)
  -"Mod Plague"=No: only forces the reproduction of plants
    -enhanced: forces SKY and FALLOW (not if these have LAVENDER segments)
  -if it has AUBURN segments and neither a consumer nor plant:
    -forces unmodified PINK
  -PLAGUE without WHITE segments:
    -other organism must reproduce ANY virus (no normal children), if it was infected by any organism
    -only 0.1 * absorption efficiency vs PLAGUE for all consuming segments except consuming SILVER
    -when a virus is forced, YELLOW does not reduce the energy of the new virus
    -when a virus is forced by non-consumer PLAGUE, AUBURN does not reduce the energy of the virus
    -"Mod Plague"=No also forces the reproduction of consumers ("Mod plague"=Yes unchanged)
    -forces RED, CREAM, OLIVE, SKY and FALLOW (not if these have LAVENDER segments)
    -Always use "Non-plant plague cost"
    -PLAGUE non consumers can force their own infection out, which immediately dies,
     if they were infected at the PLAGUE segment before (virus energy is 2)
    -enhanced: victims lavender shield energy is depleted faster for 2220 shield energy per frame  

-CORAL (transforms viruses and particles):
  -non plant and non consumers die and are transformed into the coral organism
  -if there is no place to transform the other organism just dies
  -if the other organism has less than 1.0 energy, it also dies (performance reasons) 
  -not working vs effect segments and protected segments (and not vs YELLOW, GOLD and DARKGRAY)
  -only works on SPORE segments of spore version 6
  -transforms "Mod spore" 1 spores and destroyed spores (except "Mod spore" version 6)
  -ROSE organims, that have no WHITE, CORAL or PINK segments are immune
  -if it has GOLD segments, low maintenance = 0.1 for non-plants and non-consumers
  -if it has AUBURN segments, lavender shield energy is depleted faster for 2220 shield energy per frame
  -CORAL with MAGENTA is immune for one frame vs VIOLET consumers, if not shown in color
  -enhanced: -also transforms unmodified PINK organisms

-MINT (Immune system): [also used on friends, then only altruistic] 
  -removes infections (also see "Immune system delay")
  -faster if the organism has more and longer MINT segments
  -if it touches an organism, that infected it before, the infection is recognized and removed
  -removes other organisms infection, if its MINT segments touch another 
   organism it hasn´t infected itself and both are altruists (or familial) (shown Color=CYAN)
  -removes the malus to be forced to create stillborn childs, caused by "Mod Fallow"=3
  -does the same for other organisms, if both are altruists (or familial) (shown Color=CYAN)
  -Altruist organisms don´t attack/kill/poison MINT segments      
  -destroys all WHITE, PLAGUE, CORAL, FALLOW and FRUIT segments for 1/10 MINT costs each,
   if it touches another organism, except if it touches a MINT or BLUE segment
   (but non-consumers and enhanced MINT can still destroy them by touching BLUE of a plant),
   if the other organism has WHITE, PLAGUE, CORAL or FRUIT segments
  -if the other organism is a plant or "Mod Fallow"=4 it destroys all FALLOW segments, 
   else only the FALLOW it touches
  -if an organism with MINT segments was forced to reproduce by PLAGUE with WHITE segments,
   the other organism will also gets these colors except FALLOW destroyed
  -the same vs CORAL, but even if CORAL only touches and could attack in general  
  -destroy the CREAM segment it touches
  -destroys a YELLOW segment it touches, if the other organism is infectious and not a plant or consumer
  -destroyed segments are BROKEN (plants) or BEIGE (non plants)
  -if the organism has MINT segments: being enhanced does nothing for other organisms WHITE,
   except vs NAVY and SPIKEPOINT
  -enhanced: always destroys all FALLOW segments
    
-LAVENDER (Immunity shield and recognition): [also used on friends, then only altruistic]
  -Shield vs CREAM, PLAGUE, CORAL, FALLOW and enhanced OCHRE (see Lavender shield) for all of its segments
  -If these colors attack all other segments of this organism, 
   shield energy is slowly depleted for 185 shield energy per frame (shown Color=NAVY)
  -if shield energy is 0, attacks will take effect
  -If these colors (and WHITE, but not OCHRE) attack LAVENDER (shown Color=LAVENDER), 
   shield energy is slowly restored (+200 normally, and +20 vs WHITE) and attacks have no effect, 
   but cost them life energy (0.2 normally, and 0.02 for WHITE) (shown Color=DEADBARK)
  -if WHITE has PLAGUE or FALLOW segments, it is also 200 shield for 0.2 life
  -LAVENDER costs are used to divide lost life energy for the other organisms (0.2/"LAVENDER costs") 
  -if WHITE touches, the infection will be removed immediately
  -if PLAGUE touches, and PLAGUE is the infector of this organism, the infection will also be removed
  -Shield energy is restored, formula = "(10 * total LAVENDER segment length)/symmetry"
  -if both organisms are altruists or familial, it gives the other organism shield energy (restore rate),
   if own shield energy is maxed, even if the other organism has no LAVENDER segments (shown Color=CYAN)
  -but does never give shield energy to WHITE, PLAGUE, CORAL, CREAM, FALLOW, and FRUIT segments
  -restores the time to reproduce to normal maximum delay faster, 
   if it is higher because of FALLOW, formula = "(total LAVENDER segment length)/2"
  -does the same for other organisms, if both are altruists (or familial) (shown Color=CYAN), and own
   delay to reproduce is not over maximized (not for WHITE, PLAGUE, CORAL, CREAM, FALLOW, and FRUIT)
  -Altruist organisms don´t attack/infect/kill/poison LAVENDER segments
  -low maintenance = 0.25 for plants and consumers (but not unmodified PINK)
  -low maintenance = 0.05 for everyone else
  -enhanced: -shield energy for other organisms life energy = 1000 shield for 1.0 life in all cases 
  -if the organism has MINT and LAVENDER segments:
    -The shield slowly depletes (shown Color=NAVY), when the organism can reproduce and is also infected.
    -costs are 1/10 MINT costs 
    -Reproduction is stopped until the infection is removed or the shield energy is 0 

-MAGENTA (Healing): [also used on friends] 
  -heals own segments (= restores color), see "Healing delay"
  -faster if the organism has more and longer MAGENTA segments
  -doesn´t work with lignified BARK or DEADBARK
  -heals other organisms, if both are altruists (or familial)
  -heals "Mod Spore" version 7-12
  -Altruist organisms don´t attack/infect/kill/poison MAGENTA segments
  -uses MAGENTA costs to protect itself vs FALLOW, GRAY and SKY
  -enhanced: uses MAGENTA costs to protect itself vs VIOLET, if it is not a consumer
                 
-ROSE (Friendly energy transfer): [only used on friends]
  -segment energy transfer effectivity = 2 * "Obtained energy" for family and friends (shown Color=CYAN)
  -segment energy transfer effectivity = 0.5 * "Obtained energy" for altruistic encounters
  -Altruist organisms don´t attack/infect/kill/poison ROSE segments
  -Energy is only transfered, if both organisms don´t attack each other and...
    -both organisms are altruists, 
     or both organisms are related (parent, child, sibling) and "familial", or the other organism is
     neither a plant nor a consumer, not altruistic and this organism is "peaceful" (= abuse)
    -the organism is fully grown
    -the organism has more energy (+ 2 extra energy) than the other organism for family and friends
    -and additionally needs to have more than half of its reproduce energy
     and the other organism less than half of its reproduce energy in altruistic encounters
  -Organisms with ROSE segments, that are neither plants nor consumers improve photosynthesis for plants
    -"+ Photosynthetic effectivity with symbiont * (ROSE segment length+9)" for normal photosynthesis
    -additionally + 0.25 * FOREST photosynthesis (0.375, if it has ROSE segments) for FOREST plants
    -"+ 0.125 * methanotrophic effectivity with symbiont * (ROSE segment length+9)" for methanotrophs
    - * 1.5 for both, if the photosynthetic plant or methanotroph has ROSE segments
    -only used if symbiont is not shown in color 
    -use of ROSE shows it in color for 10 frames, therefore used once in 10 frames (helps performance)
    -reproduction delay for symbionts is maximized at birth, if the symbiont has a BLOND segments
    -ROSE symbionts without WHITE or CORAL segments are invulnerable vs CORAL   
  -Low maintenance for most organisms = ROSE costs
  -Low maintenance for killer organisms = ROSE costs + 0.25 (default low maintenance is therefore 0.26)

-CYAN (Movement):
  -no changes

-TEAL (Movement and Reaction): 
  -Organism can use reaction genes (see "7. Reaction genes")   
  -Reaction is stronger, if teal segments are longer
  -allows non consumers (without WHITE, PLAGUE, CORAL, GRAY, SPIKE, LILAC, SKY, OLIVE or BLACK)
   to dodge most attacks, which means that the organism is invulnerable for one frame
   and vulnerable the next frame after being touched
  -can only dodge with harmless segments without aggressive effects (shown Color=TEAL)
   (including MINT and LAVENDER however)
  -TEAL speed is 99/100 of CYAN
  -"Passive"=No: Organism can move (like CYAN)
  -"Passive"=Yes: 
    -Organism stands still until another organism touches it
    -Maintenance costs are very low (0.05*normal)
    -Non-plants and non-consumers with WHITE, PLAGUE or CORAL can dodge too

-YELLOW (Reproduction of multiple children): 
  -one extra child per YELLOW gene (was one child per YELLOW segment)
  -+ one child for each total segment length of 23
  -formula = children += (yellow gene / symmetry) + (total yellow segment length / 23)
  -YELLOW costs are used in an reproduction attempt.

-AUBURN (extra child if infected):
  -always at least one own child if infected by another organism
  -no bonus child if not infected
  -Maintenance costs are very low (0.01*normal)
  -AUBURN costs are used in an reproduction attempt.

-INDIGO (reduces the energy a new born virus receives):
  -formula = virus reproduction energy/((total indigo segment length/"Indigo divisor") +1)
  -if the virus energy is even reduced to < 3 the virus is not born,
   the infection is removed and reproduction delay = 20 frames
  -also creates a fake target for WHITE, SILVER (only infections), PLAGUE and CORAL (if not a virus)
   so that they use "energy (minimum 0.01)/INDIGO costs" and achieve nothing (shown Color=Indigo)
  -INDIGO costs have to be >= 1 (don´t want, that WHITE/SILVER/PLAGUE use more energy than normally)
  -if the organism has MINT segments, an attack by PLAGUE (or WHITE with PLAGUE) segments on INDIGO
   will get the other organisms WHITE, PLAGUE and CORAL segments destroyed

-BLOND (reproduce early):
  -reproduction energy is reduced (not shown and normal one is used for viruses in a host)
  -not reduced, if the organism is infected
  -reduced by "total BLOND segment length + 3 for each BLOND segment"
  -minimal reproduction energy is 40 for plants, 21 for consumers, infectious ROSE viruses
   and SPORE version 6-12, and 14 for viruses and non-infectious ROSE symbionts
  -costs are (BLOND costs * (total BLOND segment length + 3 for each BLOND segment")) for plants
  -costs are BLOND costs for everyone else
  -costs are also only BLOND costs for plants with FLOWER segments
  -costs are only used, when an organism reproduces early successfully (not when infected)

-FLOWER (reproduce late):
  -reproduction energy is always increased (also shown and used if it is a virus)
  -increased by "total flower segment length - (3 * symmetry)", if the organisms has no WHITE segments,
   but reproduction energy will never be decreased
  -increased by "total flower segment length", if the organisms has WHITE segments
  -low maintenance = FLOWER costs
  -if it has no WHITE segments:
   -delay to reproduce is 0 frames, if the reproduction attempt was successful
   -delay to reproduce is 14 frames, if the reproduction attempt failed
   -if energy > 2*reproduction energy - "total flower segment length", delay to reproduce is 0 frames
   -does not lose extra energy, if the organisms energy is above reproduction energy

-GOLD (Age):
  -Life expectancy = Normal life +(GOLD segments length/GOLD costs)
  -GOLD costs = Gold life expectancy divisor
  -Maintenance costs are low (0.126*normal for plants and consumers and 0.05 for the rest)
 
-BLACK (Mimic): 
  -copies the color and reaction genes of other segments
  -does not copy photosynthesis colors, except BARK (if it is not a plant it will be OLDBARK directly)
  -Maintenance costs are very low (0.01*normal)
  -"Mod black"=No: Only changes the segment that touches the other segment
  -"Mod black"=Yes: Changes all BLACK segments to the color of the other segment

-EYE:
  -These segments do not collide, but the organism can react with TEAL to what it sees (or intersects)
  -Organisms with CYAN segments can use the reactions of the eye segment (but only the EYE segment) too
  -Other organisms can not react to them, or attack in any way
  -They do not change color, even when the organism attacks or when it dies
  -Eye segments are 1.5 * longer than normal segments
  -They have to be terminal, if they are not terminal they will change into VISION (looks like DARKFIRE)
  -If the organism has a VISION segment, its eye segments will be 2 * longer than normal segments
  -Organisms without moving segments can still use the EYE for the stop reaction (1/2 slower than normal)
  -Maintenance costs are low (0.026*normal for consumers and infectious organisms, else 0.025*normal)
  -See "7. Reaction genes" for detailed info about the possible reactions

12. Info toolbar:
  -Shows the clade of an organism (bottom row)
  -All descendents of a randomly created or pasted organism belong to the same starting clade
  -If an organism mutates and adds a gene its ID is added with a "+" to the clade
  -If an organism mutates and lost a gene its ID is added with a "-" to the clade
  -If an organism mutates and the symmetry is higher its ID is added with a ">" to the clade
  -If an organism mutates and the symmetry is lower its ID is added with a "<" to the clade
  -If an organism was imported by a corridor, other persons user name will be shown before the clade
  -You can create a user name in "Network" (maximum of 15 characters)
  -The clade string will grow, showing the ID of the first organism at the far left, 
   followed by all other organisms IDs that added genes, 
   lost genes or changed symmetry in this organisms line of ancestors
  -"Clade complexity" will limit the possible additions to that number.
  -If your limit is too high, the clade string will grow to the far right,
   and you won´t see new additions anyway.

13. Default delay to reproduce:
  -After a reproduction attempt (successful or not) an organism has to wait to try to reproduce again.
  -Delay was 20 frames in Biogenesis 0.8, now it is "8 + (6 * number of genes)" frames for all organisms.
  -If an organism exceeds 8 center segments (branching), a delay of 3 is added for each exceeding segment.
  -Reproduction attempts cost performance, and this helps to reduce some slowdowns.
  -Smaller organisms have a slight advantage in crowded settings now (competing for space to reproduce).

14. Methane (CH4) added as a new substance:
  -CH4 is produced by dead decaying organisms (and destroyed spores) and PINK feeding
  -CO2 is not produced by dead decaying organisms anymore
  -CH4 and CO2 turn into each other (adjustable in Parameters/World)
  -Can be used by methanotrophs (new color PURPLE) to generate energy
  -Intitial amount can be set in "Parameters" and can be manually increased or decreased in "Actions"

15. If you click on an infected organism, the color of the rectangle is white now, else it is orange.

16. If you start a new, or open a saved world, it will be paused immediately.
 
17. Third party improvements (Thanks to them):
  -Included Tyler Colemans "Feature Mod" (backup button):
    -see "Biogenesis Feature Mod README.txt"
    -It is possible to create automatic backups.
  -STRtrees (by Vivid Solutions) implemented by Richard David Williams
    to make the simulation run much faster.
  -Added a "Visual guide for the colors", that was originally created by a 4chan user.
    I just fixed some mistakes and made a few changes. Should help to get a quick overview.

Additional information:

Use the Biogenesis forum to ask questions, make suggestions and report bugs: 
http://sourceforge.net/projects/biogenesis/forums 
 
I created a new subreddit for the simulation here:
https://old.reddit.com/r/BiogenesisGame/

User "Kitty Tac" created a discord server for Biogenesis here (I am also active there):
https://discord.gg/EBCm9NGF8h
It is very probable, that I upload Beta versions of the Color Mod there. ;)

User "Hoophy" created a persistent Biogenesis hub world to connect your worlds to.
This world is inactive at the moment however, but he might activate it again in the future. 
If active, you can send organisms by just connecting to it, but you need to port forward, 
if you want to also receive them. If you haven´t done the latter, 
connection will also be lost after a short time.
IP: 104.198.128.253 Port: 8888
Link to his post on sourceforge, that explains it in greater detail: 
https://sourceforge.net/p/biogenesis/discussion/571709/thread/270e5daf38/

Have fun! :)

 